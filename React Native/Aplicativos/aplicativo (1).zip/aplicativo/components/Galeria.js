import React from 'react';
import { View, Text } from 'react-native';

class Galeria extends React.Component{
  render(){
    return(
      <View>
      <Text>Teste da tela "galeria" </Text>
      </View>
    );
  }
}

export default Galeria;