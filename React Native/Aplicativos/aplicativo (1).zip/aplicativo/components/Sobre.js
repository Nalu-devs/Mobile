import React from 'react';
import { View, Text, ScrollView } from 'react-native'; //ScrollView permite scrollar a tela
import Estilo from '../Estilo/Estilo';
import {Divider} from 'react-native-paper'; //serve como um hr
import { Ionicons } from '@expo/vector-icons';


//variavel global é aquela que pode ser acessivel em varios locais diferentes
const itens = ["Personagens", "História", "Estilo artistico"];

class Sobre extends React.Component{
  render(){
    return(
      <ScrollView style={Estilo.scrollViewContainer}>
        <View>
          <Text style={Estilo.bemVindoText}>Bem-vinda(o)!</Text>
        </View>
        <View>
          <Text style={Estilo.conteudoText}>Este aplicativo tem o objetivo de ensinar e mostrar informações a respeito do universo de Undertable e Deltarune.</Text>
        <Divider style={Estilo.divider}/>
        <Text style={Estilo.conteudoText}>Com esse app você ira aprender sobre:</Text>
        <View>
          {
            itens.map((item) => (
              <View>
                <Ionicons color="green" size={30} name="checkmark-circle-outline"/>
                <Text>{item}</Text>
              </View>
            ))
          }
        </View>
        </View>
      </ScrollView>
    );
  }
}

export default Sobre;
//{} serve para dizer q vai ser javascript