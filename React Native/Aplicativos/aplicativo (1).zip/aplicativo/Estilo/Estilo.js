import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  safeAreaViewConteiner:{
    backgroundColor: '#000',
    flex: '1'
  },
  scrollViewContainer:{
    backgroundColor:'#222',
  },
  bemVindoText:{
    color: '#fff',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    fontSize: 20,
    margin: 10
  },
  conteudoText:{
    margin: 20,
    color: '#fff',
    textAlign: 'justify'
  },
  divider:{
    backgroundColor:'gray',
    margin: 20,
  },
  check:{
    margin
  }
});

export const drawerStyles = {
  headerStyle:{
    backgroundColor: '#222'
  },
  headerTintColor: '#fff',
  headerTitleStyle:{
    fontWeight: 'bold'
  },
  drawerStyle:{
    backgroundColor: '#222',
    fontWeight: 'bold'
  },
  drawerActiveTintColor: '#fff',
  drawerInactiveTintColor: '#aaa',
  drawerLabelStyle:{
    color:'#0f0',
    fontSize: 16,
    fontWeight: 'bold'
  }
}