import {SafeAreaView, StatusBar} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import Estilo from './Estilo/Estilo';
//no lugar de uma view a gente pode usar o fragmento que é tag de inicio e fim sem nada dentro <></>
import { createDrawerNavigator } from '@react-navigation/drawer';
import Galeria from './components/Galeria';
import Sobre from './components/Sobre';
import { Ionicons } from '@expo/vector-icons';

import { drawerStyles } from './Estilo/Estilo'; 

const Drawer = createDrawerNavigator();

export default function App(){
  return(
    <>
      <StatusBar barStyle="dark-content" backgroundColor="#fff"/>
        <SafeAreaView style={Estilo.safeAreaViewConteiner}>
          <NavigationContainer>
            <Drawer.Navigator 
            initialRouteName="Galeria"
            screenOptions={drawerStyles}>
              <Drawer.Screen name="Sobre" component={Sobre}
              options={{//esse serve para colocar o icone
                drawerIcon: ({color, size }) =>(
                  <Ionicons name="home-outline" color={color} size={size}/>
                )
              }}
              />
              <Drawer.Screen name="Galeria" component={Galeria}
              options={{
                drawerIcon: ({color, size })=>(
                  <Ionicons name="image-outline" color={color} size={size}/>
                )
              }}
              />
            </Drawer.Navigator>
          </NavigationContainer>
        </SafeAreaView>
    </>
  );
}