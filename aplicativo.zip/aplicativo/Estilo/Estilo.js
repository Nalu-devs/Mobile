import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  safeAreaViewConteiner:{
    backgroundColor: '#000',
    flex: '1'
  }
});

export const drawerStyles = {
  headerStyle:{
    backgroundColor: '#222'
  },
  headerTintColor: '#fff',
  headerTitleStyle:{
    fontWeight: 'bold'
  },
  drawerStyle:{
    backgroundColor: '#222',
    fontWeight: 'bold'
  },
  drawerActiveTintColor: '#fff',
  drawerInactiveTintColor: '#aaa',
  drawerLabelStyle:{
    color:'#0f0',
    fontSize: 16,
    fontWeight: 'bold'

  }
}