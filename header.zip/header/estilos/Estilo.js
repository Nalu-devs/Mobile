import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  imagemLogo:{
    width: 50,
    height: 50
  },
  containerHeader:{
    backgroundColor:'#583101',
    flexDirection:'row',
    justifyContent: "space-between",
    padding: 20
  },
  divisao:{
    flexDirection:'row',
    alignItems: 'center',
    gap: 20
  },
  letra:{
    color: "white",
    fontSize: 17
  },

  fundo:{
    backgroundColor: '#e6ccb2',
    width: '100%',
    height: '100%',
  },

  containerMain:{
    padding: 20,
  },
  imagemMain:{
    alignItems: 'center',
    justifyContent: 'center'
  },
  titulo:{
    fontSize: 20,
    textAlign: 'center',
  },
  texto:{
    textAlign: "left",
    fontWeight: 'bold',
    marginTop: 20
  },
})