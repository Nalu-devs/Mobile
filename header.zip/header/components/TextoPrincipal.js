import {Text} from 'react-native';
import Estilo from '../estilos/Estilo';

export default function TextoPrincipal(props){
  return(
        <Text>{props.texto}</Text>
  )
}