import {Text} from 'react-native';
import Estilo from '../estilos/Estilo';

export default function TextoTitulo(props){
  return(
        <Text style={Estilo.texto}>{props.texto}</Text>
  )
}