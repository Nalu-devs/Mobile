import { TouchableOpacity, Text } from 'react-native';
import Estilo from '../estilos/Estilo';

export default function Link(props){
  return(
    
      <TouchableOpacity>
        <Text style={Estilo.letra}>{props.name}</Text>
      </TouchableOpacity>
    
  )
}