import { Text, View, Image} from 'react-native';
import Estilo from '../estilos/Estilo';
import TextoTitulo from './TextoTitulo';
import TextoPrincipal from './TextoPrincipal';

export default function Main(){
  return(
    <View style={Estilo.containerMain}>
      <View style={Estilo.imagemMain}>
        <Image source={require('../assets/gato.jpg')}/>
      </View>
      <Text style={Estilo.titulo}>Curiosidades Sobre Gatos</Text>

      <TextoTitulo texto="Eles ronronam por mais de um motivo"/>
      <TextoPrincipal texto="O ronronar não é só sinal de felicidade. Gatos também ronronam quando estão com dor, assustados ou tentando se acalmar — é como uma forma de auto-cura. Estudos mostram que as vibrações do ronronar (entre 25 e 150 Hz) ajudam na regeneração de tecidos e ossos."/>

      <TextoTitulo texto="Gatos têm um GPS interno"/>
      <TextoPrincipal texto="Muitos gatos conseguem voltar para casa mesmo depois de se perderem a quilômetros de distância. Eles usam o campo magnético da Terra, o olfato e sons familiares como guias."/>

      <TextoTitulo texto="O cérebro dos gatos é mais parecido com o humano do que o de um cachorro"/>
      <TextoPrincipal texto="Cerca de 90% da estrutura cerebral dos gatos é semelhante à dos humanos. Eles compartilham muitas das mesmas regiões responsáveis por emoções."/>

      <Text style={Estilo.titulo}>Vídeo fofo dos gatos</Text>
      <iframe src={"https://www.youtube.com/watch?v=-5kHNftPMc0"}/>

    </View>
  );
}