import { View, SafeAreaView, StyleSheet, ScrollView } from 'react-native';
import Header from './components/header';
import Estilo from './estilos/Estilo';
import Main from './components/Main';

export default function App() {
  return (
    <ScrollView>
    <View style={Estilo.fundo}>
      <View>
        <Header/>
        <Main/>
      </View>
    </View>
    </ScrollView>
  );
}
